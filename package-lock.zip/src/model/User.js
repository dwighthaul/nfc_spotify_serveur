const { Model } = require("sequelize");

class User extends Model {
}
module.exports = User;
