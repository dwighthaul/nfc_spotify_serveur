const { Model } = require("sequelize");
const User = require("./User");

class NFCTags extends Model {
}

module.exports = NFCTags;